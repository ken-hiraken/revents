require 'test_helper'

class TweetsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
